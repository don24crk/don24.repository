# -*- coding: utf-8 -*-
import sys
import xbmc
import xbmcplugin
import xbmcgui
import urllib.parse
import requests
import xml.etree.ElementTree as ET
import datetime

# Basic URLs and constants
PLUGIN_URL = sys.argv[0]
HANDLE = int(sys.argv[1])

# Sample playlist URL (replace with your actual playlist)
PLAYLIST_URL = "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/android.m3u"

# Global variables for EPG data
epg_channels = {https://ext.greektv.app/epg/epg.xml}  # key: channel id, value: dict with name and programs

def get_settings():
    # Fetch proxy and EPG URL from settings
    proxy_ip = xbmcaddon.Addon().getSetting('proxy_ip')
    proxy_port = xbmcaddon.Addon().getSetting('proxy_port')
    epg_url = xbmcaddon.Addon().getSetting('epg_url')
    proxy = None
    if proxy_ip and proxy_port:
        proxy = {
            'http': f'http://{proxy_ip}:{proxy_port}',
            'https': f'http://{proxy_ip}:{proxy_port}'
        }
    return proxy, epg_url

def fetch_epg(epg_url):
    proxy, _ = get_settings()
    try:
        response = requests.get(epg_url, proxies=proxy, timeout=10)
        if response.status_code == 200:
            return response.content
        else:
            xbmcgui.Dialog().ok('EPG Error', 'Failed to fetch EPG data.')
            return None
    except Exception as e:
        xbmcgui.Dialog().ok('EPG Error', str(e))
        return None

def parse_epg(xml_data):
    global epg_channels
    epg_channels = {}
    root = ET.fromstring(xml_data)
    # Parse channels
    for channel in root.findall('channel'):
        ch_id = channel.get('id')
        display_name = channel.find('display-name')
        name = display_name.text if display_name is not None else ch_id
        epg_channels[ch_id] = {
            'name': name,
            'programs': []
        }
    # Parse programs
    for prog in root.findall('programme'):
        ch_id = prog.get('channel')
        start_str = prog.get('start')
        end_str = prog.get('stop')
        start_time = parse_time(start_str)
        end_time = parse_time(end_str)
        title = prog.find('title')
        desc = prog.find('desc')
        epg_channels[ch_id]['programs'].append({
            'start': start_time,
            'end': end_time,
            'title': title.text if title is not None else 'No title',
            'desc': desc.text if desc is not None else ''
        })

def parse_time(time_str):
    # EPG times are in format: YYYYMMDDHHMMSS + timezone
    # Example: 20230101123000 +0200
    try:
        dt = datetime.datetime.strptime(time_str[:14], '%Y%m%d%H%M%S')
        return dt
    except:
        return datetime.datetime.now()

def list_main_menu():
    # Main menu options
    xbmcplugin.addDirectoryItem(HANDLE, build_url({'mode': 'categories'}), xbmcgui.ListItem('Categories'), True)
    xbmcplugin.addDirectoryItem(HANDLE, build_url({'mode': 'channels'}), xbmcgui.ListItem('All Channels'), True)
    xbmcplugin.addDirectoryItem(HANDLE, build_url({'mode': 'epg_guide'}), xbmcgui.ListItem('EPG Guide'), True)
    xbmcplugin.endOfDirectory(HANDLE)

def list_categories():
    categories = ['LIVETV', 'SEFLIX', 'SUPERMAMI', 'GREEKMOVIES', 'JESUSMOVIES', 'KIDSMOVIES', 'ALIKI VOUGIOUKLAKI TENIES']
    for cat in categories:
        xbmcplugin.addDirectoryItem(HANDLE, build_url({'mode': 'category', 'category': cat}), xbmcgui.ListItem(cat), True)
    xbmcplugin.endOfDirectory(HANDLE)

def list_channels():
    # Fetch playlist and list channels
    proxy, _ = get_settings()
    try:
        response = requests.get(PLAYLIST_URL, proxies=proxy, timeout=10)
        playlist = response.text
        # Parse playlist (simple parser for m3u)
        channels = parse_m3u(playlist)
        for ch in channels:
            li = xbmcgui.ListItem(ch['name'])
            url = build_url({'mode': 'play', 'stream_url': ch['url']})
            xbmcplugin.addDirectoryItem(HANDLE, url, li, False)
        xbmcplugin.endOfDirectory(HANDLE)
    except Exception as e:
        xbmcgui.Dialog().ok('Error', str(e))

def parse_m3u(data):
    channels = []
    lines = data.splitlines()
    for i in range(len(lines)):
        if lines[i].startswith('#EXTINF'):
            info = lines[i]
            url = lines[i+1] if i+1 < len(lines) else ''
            name = info.split('title="')[-1].split('"')[0]
            channels.append({'name': name, 'url': url})
    return channels

def list_epg_guide():
    # Fetch and parse EPG
    xml_data = fetch_epg()
    if xml_data:
        parse_epg(xml_data)
        list_epg_channels()

def list_epg_channels():
    # List channels from EPG
    for ch_id, ch in epg_channels.items():
        li = xbmcgui.ListItem(ch['name'])
        url = build_url({'mode': 'epg_channel', 'channel_id': ch_id})
        xbmcplugin.addDirectoryItem(HANDLE, url, li, True)
    xbmcplugin.endOfDirectory(HANDLE)

def list_epg_channel():
    args = sys.argv[2]
    params = urllib.parse.parse_qs(args[1:])
    ch_id = params.get('channel_id', [None])[0]
    if ch_id and ch_id in epg_channels:
        ch = epg_channels[ch_id]
        now = datetime.datetime.now()
        for prog in ch['programs']:
            start = prog['start']
            end = prog['end']
            label = f"{start.strftime('%H:%M')} - {end.strftime('%H:%M')} {prog['title']}"
            li = xbmcgui.ListItem(label)
            li.setInfo('video', {'title': prog['title'], 'plot': prog['desc']})
            xbmcplugin.addDirectoryItem(HANDLE, '', li, False)
        xbmcplugin.endOfDirectory(HANDLE)

def build_url(query):
    return f"{PLUGIN_URL}?{urllib.parse.urlencode(query)}"

def main():
    mode = None
    if len(sys.argv) > 2:
        args = sys.argv[2]
        params = urllib.parse.parse_qs(args[1:])
        mode = params.get('mode', [None])[0]
    else:
        mode = None

    if mode is None:
        list_main_menu()
    elif mode == 'categories':
        list_categories()
    elif mode == 'channel':
        list_channels()
    elif mode == 'epg_guide':
        list_epg_guide()
    elif mode == 'epg_channel':
        list_epg_channel()
    elif mode == 'play':
        stream_url = sys.argv[2].split('stream_url=')[-1]
        play_stream(stream_url)

def play_stream(url):
    li = xbmcgui.ListItem('Playing Stream')
    li.setInfo('video', {'title': 'Stream'})
    xbmcplugin.setResolvedUrl(HANDLE, True, li)

if __name__ == '__main__':
    main()