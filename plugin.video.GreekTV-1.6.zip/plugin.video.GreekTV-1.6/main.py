import sys
import urllib.parse
import requests
import xbmcgui
import xbmcplugin
import xbmcaddon
import re

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

CATEGORIES = [
    "LiveTV", "SEFLIX", "GREEKMOVIES", 
    "JESUSMOVIES", "KIDSMOVIES", "ALIKI VOUGIOUKLAKI TENIES"
]

def get_proxy():
    if ADDON.getSetting('use_proxy') == 'true':
        ip = ADDON.getSetting('proxy_ip')
        port = ADDON.getSetting('proxy_port')
        user = ADDON.getSetting('proxy_user')
        pw = ADDON.getSetting('proxy_pass')
        
        if user and pw:
            proxy = f"http://{user}:{pw}@{ip}:{port}"
        else:
            proxy = f"http://{ip}:{port}"
        return {"http": proxy, "https": proxy}
    return None

def fetch_m3u():
    url = ADDON.getSetting('m3u_url')
    proxies = get_proxy()
    try:
        response = requests.get(url, proxies=proxies, timeout=10)
        return response.text
    except:
        return ""

def parse_m3u(category_filter):
    content = fetch_m3u()
    # Regex to find #EXTINF and URL
    pattern = r'#EXTINF:.*group-title="(?P<group>.*?)".*tvg-logo="(?P<logo>.*?)".*,(?P<name>.*?)\n(?P<url>http.*)'
    matches = re.finditer(pattern, content, re.MULTILINE)
    
    items = []
    for match in matches:
        if category_filter.lower() in match.group('group').lower():
            items.append({
                'name': match.group('name').strip(),
                'url': match.group('url').strip(),
                'logo': match.group('logo').strip()
            })
    return items

def main_menu():
    for cat in CATEGORIES:
        url = f"{BASE_URL}?action=list&category={urllib.parse.quote_plus(cat)}"
        li = xbmcgui.ListItem(cat)
        li.setArt({'icon': "resources/icon.png", 'fanart': "resources/fanart.jpg"})
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)

def list_channels(category):
    channels = parse_m3u(category)
    for ch in channels:
        url = f"{BASE_URL}?action=play&url={urllib.parse.quote_plus(ch['url'])}"
        li = xbmcgui.ListItem(ch['name'])
        li.setArt({'thumb': ch['logo'], 'icon': ch['logo']})
        li.setInfo('video', {'title': ch['name'], 'plot': f"Category: {category}"})
        li.setProperty('IsPlayable', 'true')
        
        # Set EPG Data if available
        epg_url = ADDON.getSetting('epg_url')
        if epg_url:
            li.setProperty('inputstream.adaptive.manifest_type', 'hls')
        
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE)

def play_video(path):
    li = xbmcgui.ListItem(path)
    # Apply proxy headers to stream if needed
    if ADDON.getSetting('use_proxy') == 'true':
        path += f"|http-proxy={ADDON.getSetting('proxy_ip')}:{ADDON.getSetting('proxy_port')}"
    
    xbmcplugin.setResolvedUrl(HANDLE, True, xbmcgui.ListItem(path=path))

# Router
params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
action = params.get('action')

if not action:
    main_menu()
elif action == 'list':
    list_channels(params.get('category'))
elif action == 'play':
    play_video(params.get('url'))