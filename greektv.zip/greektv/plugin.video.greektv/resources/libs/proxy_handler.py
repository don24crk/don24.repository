# -*- coding: utf-8 -*-
"""
Proxy Handler for GreekTV
"""

import urllib.request
import urllib.parse
from .. import log

class ProxyHandler:
    """Proxy Handler Class"""
    
    def __init__(self):
        self.enabled = False
        self.proxy_type = 'HTTP'
        self.proxy_ip = ''
        self.proxy_port = ''
        self.username = ''
        self.password = ''
        self.proxy_url = None
    
    def configure(self, proxy_type='HTTP', proxy_ip='', proxy_port='', username='', password=''):
        """Configure proxy settings"""
        self.proxy_type = proxy_type.upper()
        self.proxy_ip = proxy_ip
        self.proxy_port = proxy_port
        self.username = username
        self.password = password
        
        if proxy_ip and proxy_port:
            self.enabled = True
            self.build_proxy_url()
        else:
            self.enabled = False
    
    def build_proxy_url(self):
        """Build proxy URL"""
        if not self.proxy_ip or not self.proxy_port:
            self.proxy_url = None
            return
        
        auth = ''
        if self.username and self.password:
            auth = f'{urllib.parse.quote(self.username)}:{urllib.parse.quote(self.password)}@'
        
        protocol = self.proxy_type.lower()
        self.proxy_url = f'{protocol}://{auth}{self.proxy_ip}:{self.proxy_port}'
        
        log(f"Proxy configured: {protocol}://{self.proxy_ip}:{self.proxy_port}")
    
    def get_proxy_url(self, original_url=''):
        """Get proxy URL for a given original URL"""
        if not self.enabled:
            return original_url
        return original_url
    
    def apply_proxy(self, request):
        """Apply proxy to request"""
        if not self.enabled or not self.proxy_url:
            return request
        
        proxy_handler = urllib.request.ProxyHandler({
            self.proxy_type.lower(): self.proxy_url
        })
        
        opener = urllib.request.build_opener(proxy_handler)
        return request
    
    def get_opener(self):
        """Get opener with proxy configured"""
        if not self.enabled:
            return urllib.request.urlopen
        
        proxy_handler = urllib.request.ProxyHandler({
            self.proxy_type.lower(): self.proxy_url
        })
        
        opener = urllib.request.build_opener(proxy_handler)
        return opener.open
    
    def is_enabled(self):
        """Check if proxy is enabled"""
        return self.enabled
    
    def test_connection(self):
        """Test proxy connection"""
        if not self.enabled:
            return False, "Proxy not configured"
        
        try:
            test_url = 'https://www.google.com'
            opener = self.get_opener()
            response = opener(test_url, timeout=10)
            return True, "Connection successful"
        except Exception as e:
            return False, str(e)