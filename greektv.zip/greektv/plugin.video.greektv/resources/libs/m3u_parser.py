# -*- coding: utf-8 -*-
"""
M3U Playlist Parser
"""

import re
import urllib.request
import urllib.error
from .. import log

class M3UParser:
    """M3U Playlist Parser Class"""
    
    CACHE = {}
    CACHE_TIME = 300  # 5 minutes cache
    
    def __init__(self):
        self.headers = {
            'User-Agent': 'GreekTV/1.0.3 (Kodi 21.3)',
            'Accept': '*/*',
            'Connection': 'keep-alive'
        }
    
    def fetch_playlist(self, url, proxy_handler=None):
        """Fetch M3U playlist from URL"""
        import time
        
        # Check cache
        cache_key = url
        if cache_key in self.CACHE:
            cached_data, cached_time = self.CACHE[cache_key]
            if time.time() - cached_time < self.CACHE_TIME:
                log("Using cached playlist")
                return cached_data
        
        try:
            log(f"Fetching playlist: {url}")
            
            # Build request
            req = urllib.request.Request(url, headers=self.headers)
            
            # Add proxy if configured
            if proxy_handler:
                req = proxy_handler.apply_proxy(req)
            
            # Fetch content
            response = urllib.request.urlopen(req, timeout=30)
            content = response.read().decode('utf-8', errors='ignore')
            
            # Cache result
            self.CACHE[cache_key] = (content, time.time())
            
            return content
            
        except urllib.error.HTTPError as e:
            log(f"HTTP Error: {e.code} - {e.reason}", log=xbmc.LOGERROR)
            raise Exception(f"HTTP Error: {e.code}")
        except urllib.error.URLError as e:
            log(f"URL Error: {e.reason}", log=xbmc.LOGERROR)
            raise Exception(f"URL Error: {e.reason}")
        except Exception as e:
            log(f"Error fetching playlist: {e}", log=xbmc.LOGERROR)
            raise
    
    def parse_m3u(self, content):
        """Parse M3U content"""
        items = []
        lines = content.split('\n')
        
        current_item = None
        in_info = False
        
        for line in lines:
            line = line.strip()
            
            if not line:
                continue
            
            # Skip extended info header
            if line.startswith('#EXTINF:'):
                in_info = True
                current_item = self.parse_extinf(line)
            elif line.startswith('#EXTVLCOPT:'):
                if current_item:
                    option = line.replace('#EXTVLCOPT:', '').strip()
                    if 'http-referrer' in option.lower():
                        current_item['referrer'] = option.split('=')[-1]
            elif line.startswith('#EXTGRP:'):
                if current_item:
                    current_item['group'] = line.replace('#EXTGRP:', '').strip()
            elif line.startswith('#'):
                # Other extended info
                continue
            elif current_item:
                # This is the URL
                current_item['url'] = line
                items.append(current_item)
                current_item = None
                in_info = False
        
        return items
    
    def parse_extinf(self, line):
        """Parse #EXTINF line"""
        item = {
            'name': 'Unknown',
            'logo': '',
            'tvg_id': '',
            'tvg_name': '',
            'group': '',
            'url': ''
        }
        
        # Parse main attributes
        # Format: #EXTINF:-1 tvg-id="xxx" tvg-name="xxx" tvg-logo="xxx" group-title="xxx",Name
        match = re.match(r'#EXTINF:([-\d]+)\s*(.*?),(.*)', line)
        
        if match:
            duration = match.group(1)
            attributes = match.group(2)
            name = match.group(3).strip()
            
            item['name'] = name
            item['duration'] = int(duration) if duration.isdigit() else 0
            
            # Parse attributes
            # tvg-id
            tvg_id_match = re.search(r'tvg-id="([^"]*)"', attributes)
            if tvg_id_match:
                item['tvg_id'] = tvg_id_match.group(1)
            
            # tvg-name
            tvg_name_match = re.search(r'tvg-name="([^"]*)"', attributes)
            if tvg_name_match:
                item['tvg_name'] = tvg_name_match.group(1)
            
            # tvg-logo
            tvg_logo_match = re.search(r'tvg-logo="([^"]*)"', attributes)
            if tvg_logo_match:
                item['logo'] = tvg_logo_match.group(1)
            
            # group-title
            group_match = re.search(r'group-title="([^"]*)"', attributes)
            if group_match:
                item['group'] = group_match.group(1)
            
            # catchup
            catchup_match = re.search(r'catchup-type="([^"]*)"', attributes)
            if catchup_match:
                item['catchup_type'] = catchup_match.group(1)
        
        return item
    
    def get_items_by_category(self, url, category, proxy_handler=None):
        """Get items filtered by category"""
        try:
            content = self.fetch_playlist(url, proxy_handler)
            all_items = self.parse_m3u(content)
            
            # Normalize category for matching
            category_lower = category.lower()
            category_mapping = {
                'livetv': ['livetv', 'live tv', 'live-tv', 'live', 'ζωντανή', 'live tv'],
                'seflix': ['seflix', 'series', 'seires', 'σειρές', 'shows'],
                'greekmovies': ['greekmovies', 'greek movies', 'ελληνικές ταινίες', 'greek films'],
                'jesusmovies': ['jesusmovies', 'jesus', 'christian', 'χριστιανικές', 'θρησκευτικές'],
                'kidsmovies': ['kidsmovies', 'kids', 'παιδικά', 'children', 'cartoons'],
                'aliki': ['aliki', 'βουγιουκλάκη', 'vougiouklaki']
            }
            
            matching_groups = category_mapping.get(category_lower, [category_lower])
            
            filtered_items = []
            for item in all_items:
                item_group = item.get('group', '').lower()
                item_name = item.get('name', '').lower()
                
                # Check if item matches category
                for match_group in matching_groups:
                    if match_group in item_group or match_group in item_name:
                        filtered_items.append(item)
                        break
            
            return filtered_items
            
        except Exception as e:
            log(f"Error getting items by category: {e}", xbmc.LOGERROR)
            return []
    
    def search_items(self, url, query, proxy_handler=None):
        """Search items by query"""
        try:
            content = self.fetch_playlist(url, proxy_handler)
            all_items = self.parse_m3u(content)
            
            query_lower = query.lower()
            results = []
            
            for item in all_items:
                name = item.get('name', '').lower()
                group = item.get('group', '').lower()
                
                if query_lower in name or query_lower in group:
                    results.append(item)
            
            return results
            
        except Exception as e:
            log(f"Error searching items: {e}", xbmc.LOGERROR)
            return []
    
    def clear_cache(self):
        """Clear parsed content cache"""
        self.CACHE = {}