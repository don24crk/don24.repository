# -*- coding: utf-8 -*-
"""
GreekTV Main Module
Version: 1.0.3
"""

import sys
import os
import re
import json
import time
import urllib.request
import urllib.parse
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

# Constants
ADDON = xbmcaddon.Addon('plugin.video.greektv')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_VERSION = ADDON.getAddonInfo('version')
ADDON_PATH = ADDON.getAddonInfo('path')
ADDON_ICON = os.path.join(ADDON_PATH, 'resources', 'media', 'icon.png')
ADDON_FANART = os.path.join(ADDON_PATH, 'resources', 'media', 'fanart.jpg')

HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

CATEGORIES = {
    'LiveTV': {'name': 'LiveTV', 'desc': 'Greek Live TV Channels'},
    'SEFLIX': {'name': 'SEFLIX', 'desc': 'Greek Series'},
    'GREEKMOVIES': {'name': 'GREEKMOVIES', 'desc': 'Greek Movies'},
    'JESUSMOVIES': {'name': 'JESUSMOVIES', 'desc': 'Christian Movies'},
    'KIDSMOVIES': {'name': 'KIDSMOVIES', 'desc': 'Kids Movies'},
    'ALIKI': {'name': 'ALIKI', 'desc': 'Aliki Vougiouklaki'}
}

def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[{ADDON_NAME}] {msg}", level)

def notify(title, msg, icon='', time=5000):
    if not icon:
        icon = ADDON_ICON
    xbmcgui.Dialog().notification(title, msg, icon, time)

def get_setting(key, default=''):
    try:
        val = ADDON.getSetting(key)
        return val if val else default
    except:
        return default

def set_setting(key, value):
    try:
        ADDON.setSetting(key, value)
        return True
    except:
        return False

def build_url(params):
    return f"{BASE_URL}?{urllib.parse.urlencode(params)}"

def parse_params():
    params = {}
    param_str = sys.argv[2]
    if param_str:
        params = dict(urllib.parse.parse_qsl(urllib.parse.unquote_plus(param_str)))
    return params

class M3UParser:
    """M3U Playlist Parser"""
    
    def __init__(self):
        self.cache = {}
        self.cache_time = 300
    
    def fetch(self, url, proxy=None):
        import time
        if url in self.cache:
            data, timestamp = self.cache[url]
            if time.time() - timestamp < self.cache_time:
                return data
        
        try:
            log(f"Fetching: {url}")
            req = urllib.request.Request(url, headers={'User-Agent': 'GreekTV/1.0'})
            
            if proxy and proxy.get('enabled'):
                pass
            
            response = urllib.request.urlopen(req, timeout=30)
            data = response.read().decode('utf-8', errors='ignore')
            self.cache[url] = (data, time.time())
            return data
        except Exception as e:
            log(f"Fetch error: {e}", xbmc.LOGERROR)
            raise
    
    def parse(self, content):
        items = []
        lines = content.split('\n')
        item = None
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
            
            if line.startswith('#EXTINF:'):
                match = re.match(r'#EXTINF:([-\d]+)\s*(.*?),(.*)', line)
                if match:
                    attrs = match.group(2)
                    name = match.group(3).strip()
                    
                    item = {'name': name, 'url': '', 'logo': ''}
                    
                    logo_match = re.search(r'tvg-logo="([^"]*)"', attrs)
                    if logo_match:
                        item['logo'] = logo_match.group(1)
                    
                    group_match = re.search(r'group-title="([^"]*)"', attrs)
                    if group_match:
                        item['group'] = group_match.group(1)
                    
                    tvg_id = re.search(r'tvg-id="([^"]*)"', attrs)
                    if tvg_id:
                        item['tvg_id'] = tvg_id.group(1)
            
            elif line.startswith('#'):
                continue
            
            elif item and not item.get('url'):
                item['url'] = line
                items.append(item)
                item = None
        
        return items
    
    def get_by_category(self, url, category, proxy=None):
        try:
            content = self.fetch(url, proxy)
            all_items = self.parse(content)
            
            cat_lower = category.lower()
            results = []
            
            for item in all_items:
                group = item.get('group', '').lower()
                name = item.get('name', '').lower()
                
                if cat_lower in group or cat_lower in name:
                    results.append(item)
            
            return results
        except:
            return []
    
    def search(self, url, query, proxy=None):
        try:
            content = self.fetch(url, proxy)
            all_items = self.parse(content)
            
            query_lower = query.lower()
            return [i for i in all_items if query_lower in i.get('name', '').lower()]
        except:
            return []

class Main:
    """Main Addon Class"""
    
    def __init__(self):
        self.params = parse_params()
        self.mode = self.params.get('mode', '')
        self.parser = M3UParser()
        
        self.m3u_url = get_setting('m3u_playlist_url')
        self.epg_url = get_setting('epg_url')
        self.proxy_enabled = get_setting('proxy_enabled') == 'true'
        self.proxy_ip = get_setting('proxy_ip')
        self.proxy_port = get_setting('proxy_port')
        
        proxy = None
        if self.proxy_enabled:
            proxy = {'enabled': True, 'ip': self.proxy_ip, 'port': self.proxy_port}
        self.proxy = proxy
    
    def run(self):
        log(f"Mode: {self.mode}")
        
        if self.mode == 'category_items':
            self.show_items()
        elif self.mode == 'play':
            self.play()
        elif self.mode == 'search':
            self.search()
        elif self.mode == 'setup_m3u':
            self.setup_m3u()
        elif self.mode == 'settings':
            ADDON.openSettings()
        elif self.mode == 'refresh':
            xbmc.executebuiltin('Container.Refresh')
        else:
            self.main_menu()
    
    def main_menu(self):
        """Show main menu"""
        self.add_dir('Settings', 'settings', True)
        
        for cat_id, cat in CATEGORIES.items():
            show_key = f"show_{cat_id.lower()}"
            if get_setting(show_key, 'true') == 'false':
                continue
            self.add_dir(f"📺 {cat['name']}", 'category_items', True, cat_id)
        
        self.add_dir('🔍 Search', 'search', True)
        
        xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=True)
    
    def show_items(self):
        """Show category items"""
        category = self.params.get('category', '')
        
        if not category:
            notify(ADDON_NAME, 'No category selected')
            return
        
        items = []
        
        if self.m3u_url:
            items = self.parser.get_by_category(self.m3u_url, category, self.proxy)
        
        if not items:
            items = self.get_demos(category)
        
        for item in items:
            self.add_video(item)
        
        xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=True)
    
    def get_demos(self, category):
        """Demo items"""
        demos = {
            'LiveTV': [
                {'name': 'ERT1', 'url': 'http://example.com/ert1.m3u8', 'logo': ''},
                {'name': 'ERT2', 'url': 'http://example.com/ert2.m3u8', 'logo': ''},
                {'name': 'ANTENA', 'url': 'http://example.com/antena.m3u8', 'logo': ''},
                {'name': 'STAR', 'url': 'http://example.com/star.m3u8', 'logo': ''},
                {'name': 'ALPHA', 'url': 'http://example.com/alpha.m3u8', 'logo': ''},
                {'name': 'MEGA', 'url': 'http://example.com/mega.m3u8', 'logo': ''},
                {'name': 'SKAI', 'url': 'http://example.com/skai.m3u8', 'logo': ''},
            ],
            'SEFLIX': [
                {'name': 'Σασμός - Episode 1', 'url': 'http://example.com/s1.m3u8', 'logo': ''},
                {'name': 'Σασμός - Episode 2', 'url': 'http://example.com/s2.m3u8', 'logo': ''},
                {'name': 'Γη Ελαφράς Φωτιάς', 'url': 'http://example.com/ge.m3u8', 'logo': ''},
            ],
            'GREEKMOVIES': [
                {'name': 'Λαβ Καίσαρ', 'url': 'http://example.com/lab.m3u8', 'logo': ''},
                {'name': 'Η Νίκη Την Καλεί', 'url': 'http://example.com/niki.m3u8', 'logo': ''},
            ],
            'JESUSMOVIES': [
                {'name': 'Ο Υιός του Θεού', 'url': 'http://example.com/yios.m3u8', 'logo': ''},
                {'name': 'Η Βασιλεία των Ουρανών', 'url': 'http://example.com/vas.m3u8', 'logo': ''},
            ],
            'KIDSMOVIES': [
                {'name': 'Ο Μικρός Νικόλας', 'url': 'http://example.com/nik.m3u8', 'logo': ''},
                {'name': 'Τα Τέσσερα Φτερά', 'url': 'http://example.com/ft.m3u8', 'logo': ''},
            ],
            'ALIKI': [
                {'name': 'Η Αλίκη στα Σόσιαλ', 'url': 'http://example.com/a1.m3u8', 'logo': ''},
                {'name': 'Κατηγορώ την Μοίρα μου', 'url': 'http://example.com/a2.m3u8', 'logo': ''},
                {'name': 'Προσοχή Μωρό μου', 'url': 'http://example.com/a3.m3u8', 'logo': ''},
            ]
        }
        return demos.get(category, [])
    
    def add_dir(self, title, mode, is_folder, category=''):
        icon = ADDON_ICON
        if os.path.exists(icon):
            icon = icon
        else:
            icon = ''
        
        li = xbmcgui.ListItem(label=title)
        li.setArt({'icon': icon, 'fanart': ADDON_FANART})
        
        url = build_url({'mode': mode, 'category': category})
        xbmcplugin.addDirectoryItem(HANDLE, url, li, is_folder)
    
    def add_video(self, item):
        title = item.get('name', 'Unknown')
        url = item.get('url', '')
        logo = item.get('logo', '') or ADDON_ICON
        
        li = xbmcgui.ListItem(label=title)
        li.setArt({'icon': logo, 'fanart': ADDON_FANART, 'thumb': logo})
        li.setInfo('video', {'title': title})
        li.setProperty('IsPlayable', 'true')
        
        play_url = build_url({'mode': 'play', 'url': url, 'name': title})
        xbmcplugin.addDirectoryItem(HANDLE, play_url, li, False)
    
    def play(self):
        url = self.params.get('url', '')
        name = self.params.get('name', 'Video')
        
        if not url:
            notify(ADDON_NAME, 'No URL')
            return
        
        li = xbmcgui.ListItem(label=name)
        li.setPath(url)
        li.setProperty('IsPlayable', 'true')
        
        xbmcplugin.setResolvedUrl(HANDLE, True, li)
    
    def search(self):
        query = xbmcgui.Dialog().input('Search', type=xbmcgui.INPUT_ALPHANUM)
        
        if not query:
            return
        
        items = []
        if self.m3u_url:
            items = self.parser.search(self.m3u_url, query, self.proxy)
        
        for item in items:
            self.add_video(item)
        
        xbmcplugin.endOfDirectory(HANDLE)
    
    def setup_m3u(self):
        current = get_setting('m3u_playlist_url')
        url = xbmcgui.Dialog().input('Enter M3U URL', defaultt=current, type=xbmcgui.INPUT_ALPHANUM)
        
        if url:
            set_setting('m3u_playlist_url', url)
            notify(ADDON_NAME, 'URL updated')