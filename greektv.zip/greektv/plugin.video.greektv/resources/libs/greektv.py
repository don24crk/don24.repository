# -*- coding: utf-8 -*-
"""
GreekTV - Main Plugin
Version: 1.0.3
"""

import sys
import os
import re
import urllib.request
import urllib.parse
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON = xbmcaddon.Addon('plugin.video.greektv')
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_VERSION = ADDON.getAddonInfo('version')
ADDON_PATH = ADDON.getAddonInfo('path')
ADDON_ICON = os.path.join(ADDON_PATH, 'resources', 'media', 'icon.png')
ADDON_FANART = os.path.join(ADDON_PATH, 'resources', 'media', 'fanart.jpg')

HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

CATS = {
    'LiveTV': 'Greek Live TV',
    'SEFLIX': 'Greek Series',
    'GREEKMOVIES': 'Greek Movies',
    'JESUSMOVIES': 'Christian Movies',
    'KIDSMOVIES': 'Kids Movies',
    'ALIKI': 'Aliki Vougiouklaki'
}

def log(msg):
    xbmc.log(f"[{ADDON_NAME}] {msg}", xbmc.LOGINFO)

def get_setting(key, default=''):
    try:
        val = ADDON.getSetting(key)
        return val if val else default
    except:
        return default

def set_setting(key, value):
    try:
        ADDON.setSetting(key, str(value))
        return True
    except:
        return False

def url(params):
    return f"{BASE_URL}?{urllib.parse.urlencode(params)}"

def params():
    s = sys.argv[2]
    if not s:
        return {}
    return dict(urllib.parse.parse_qsl(urllib.parse.unquote_plus(s)))

class Parser:
    def fetch(self, url):
        req = urllib.request.Request(url, headers={'User-Agent': 'GreekTV/1.0'})
        resp = urllib.request.urlopen(req, timeout=30)
        return resp.read().decode('utf-8', errors='ignore')
    
    def parse(self, text):
        items = []
        current = None
        for line in text.split('\n'):
            line = line.strip()
            if not line:
                continue
            if line.startswith('#EXTINF:'):
                m = re.match(r'#EXTINF:([-\d]+)\s*(.*?),(.*)', line)
                if m:
                    attrs = m.group(2)
                    name = m.group(3).strip()
                    current = {'name': name, 'url': '', 'logo': '', 'group': ''}
                    lm = re.search(r'tvg-logo="([^"]*)"', attrs)
                    if lm:
                        current['logo'] = lm.group(1)
                    gm = re.search(r'group-title="([^"]*)"', attrs)
                    if gm:
                        current['group'] = gm.group(1)
            elif current and not current['url'] and not line.startswith('#'):
                current['url'] = line
                items.append(current)
                current = None
        return items
    
    def get_by_cat(self, m3u_url, cat):
        try:
            text = self.fetch(m3u_url)
            items = self.parse(text)
            cat_lower = cat.lower()
            return [i for i in items if cat_lower in i.get('group', '').lower() or cat_lower in i.get('name', '').lower()]
        except Exception as e:
            log(f"Parse error: {e}")
            return []

class GreekTV:
    def __init__(self):
        self.params = params()
        self.mode = self.params.get('mode', '')
        self.parser = Parser()
        self.m3u_url = get_setting('m3u_url')
        self.proxy_on = get_setting('proxy_enable') == 'true'
        self.proxy_ip = get_setting('proxy_ip')
        self.proxy_port = get_setting('proxy_port')
    
    def run(self):
        log(f"Mode: {self.mode}")
        if self.mode == 'category_items':
            self.show_items()
        elif self.mode == 'play':
            self.play()
        elif self.mode == 'search':
            self.search()
        elif self.mode == 'settings':
            ADDON.openSettings()
        else:
            self.main_menu()
    
    def main_menu(self):
        self.add_item('Settings', 'settings', True)
        for cat_id, cat_name in CATS.items():
            if get_setting(f'cat_{cat_id.lower()}', 'true') == 'false':
                continue
            self.add_item(f'📺 {cat_name}', 'category_items', True, cat_id)
        self.add_item('🔍 Search', 'search', True)
        xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=True)
    
    def show_items(self):
        cat = self.params.get('category', '')
        if not cat:
            xbmcgui.Dialog().notification(ADDON_NAME, 'No category')
            return
        
        items = []
        if self.m3u_url:
            items = self.parser.get_by_cat(self.m3u_url, cat)
        
        if not items:
            items = self.demos.get(cat, [])
        
        for item in items:
            self.add_video(item)
        
        xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=True)
    
    demos = {
        'LiveTV': [
            {'name': 'ERT1', 'url': 'http://example.com/ert1.m3u8'},
            {'name': 'ERT2', 'url': 'http://example.com/ert2.m3u8'},
            {'name': 'ANTENA', 'url': 'http://example.com/antena.m3u8'},
            {'name': 'STAR', 'url': 'http://example.com/star.m3u8'},
            {'name': 'ALPHA', 'url': 'http://example.com/alpha.m3u8'},
            {'name': 'MEGA', 'url': 'http://example.com/mega.m3u8'},
            {'name': 'SKAI', 'url': 'http://example.com/skai.m3u8'},
        ],
        'SEFLIX': [
            {'name': 'Σασμός EP1', 'url': 'http://example.com/s1.m3u8'},
            {'name': 'Σασμός EP2', 'url': 'http://example.com/s2.m3u8'},
            {'name': 'Γη Ελαφράς Φωτιάς', 'url': 'http://example.com/ge.m3u8'},
            {'name': 'Η Γειτονιά μου', 'url': 'http://example.com/gm.m3u8'},
        ],
        'GREEKMOVIES': [
            {'name': 'Λαβ Καίσαρ', 'url': 'http://example.com/lab.m3u8'},
            {'name': 'Η Νίκη Την Καλεί', 'url': 'http://example.com/niki.m3u8'},
            {'name': 'Μανταλένα', 'url': 'http://example.com/mant.m3u8'},
        ],
        'JESUSMOVIES': [
            {'name': 'Ο Υιός του Θεού', 'url': 'http://example.com/yios.m3u8'},
            {'name': 'Η Βασιλεία των Ουρανών', 'url': 'http://example.com/vas.m3u8'},
        ],
        'KIDSMOVIES': [
            {'name': 'Ο Μικρός Νικόλας', 'url': 'http://example.com/nik.m3u8'},
            {'name': 'Τα Τέσσερα Φτερά', 'url': 'http://example.com/ft.m3u8'},
        ],
        'ALIKI': [
            {'name': 'Η Αλίκη στα Σόσιαλ', 'url': 'http://example.com/a1.m3u8'},
            {'name': 'Κατηγορώ την Μοίρα μου', 'url': 'http://example.com/a2.m3u8'},
            {'name': 'Προσοχή Μωρό μου', 'url': 'http://example.com/a3.m3u8'},
            {'name': 'Κάτι Να Κάψει', 'url': 'http://example.com/a4.m3u8'},
            {'name': 'Μια Γυναίκα Έκανε τον Ντίκ', 'url': 'http://example.com/a5.m3u8'},
        ]
    }
    
    def add_item(self, title, mode, folder, cat=''):
        li = xbmcgui.ListItem(label=title)
        li.setArt({'icon': ADDON_ICON, 'fanart': ADDON_FANART})
        u = url({'mode': mode, 'category': cat})
        xbmcplugin.addDirectoryItem(HANDLE, u, li, folder)
    
    def add_video(self, item):
        title = item.get('name', 'Unknown')
        video_url = item.get('url', '')
        logo = item.get('logo', '') or ADDON_ICON
        
        li = xbmcgui.ListItem(label=title)
        li.setArt({'icon': logo, 'fanart': ADDON_FANART, 'thumb': logo})
        li.setInfo('video', {'title': title})
        li.setProperty('IsPlayable', 'true')
        
        play_url = url({'mode': 'play', 'url': video_url})
        xbmcplugin.addDirectoryItem(HANDLE, play_url, li, False)
    
    def play(self):
        video_url = self.params.get('url', '')
        if not video_url:
            xbmcgui.Dialog().notification(ADDON_NAME, 'No URL')
            return
        
        li = xbmcgui.ListItem()
        li.setPath(video_url)
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.setResolvedUrl(HANDLE, True, li)
    
    def search(self):
        query = xbmcgui.Dialog().input('Search', type=xbmcgui.INPUT_ALPHANUM)
        if not query:
            return
        
        if self.m3u_url:
            try:
                text = self.parser.fetch(self.m3u_url)
                items = self.parser.parse(text)
                results = [i for i in items if query.lower() in i.get('name', '').lower()]
                for item in results:
                    self.add_video(item)
            except:
                pass
        
        xbmcplugin.endOfDirectory(HANDLE)