# -*- coding: utf-8 -*-
"""
EPG Handler for GreekTV
"""

import re
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta
from .. import log

class EPGHandler:
    """EPG Handler Class"""
    
    CACHE = {}
    CACHE_TIME = 300
    
    def __init__(self):
        self.headers = {
            'User-Agent': 'GreekTV/1.0.3 (Kodi 21.3)',
            'Accept': '*/*',
            'Connection': 'keep-alive'
        }
    
    def fetch_epg(self, url, proxy_handler=None):
        """Fetch EPG data from URL"""
        import time
        import urllib.request
        
        cache_key = url
        if cache_key in self.CACHE:
            cached_data, cached_time = self.CACHE[cache_key]
            if time.time() - cached_time < self.CACHE_TIME:
                log("Using cached EPG data")
                return cached_data
        
        try:
            log(f"Fetching EPG: {url}")
            
            req = urllib.request.Request(url, headers=self.headers)
            
            if proxy_handler:
                req = proxy_handler.apply_proxy(req)
            
            response = urllib.request.urlopen(req, timeout=30)
            content = response.read().decode('utf-8', errors='ignore')
            
            self.CACHE[cache_key] = (content, time.time())
            return content
            
        except Exception as e:
            log(f"Error fetching EPG: {e}", xbmc.LOGERROR)
            raise
    
    def parse_xmltv(self, content):
        """Parse XMLTV format EPG"""
        programs = []
        
        try:
            root = ET.fromstring(content)
            
            for channel in root.findall('.//channel'):
                channel_id = channel.get('id', '')
                display_name = channel.find('.//display-name')
                channel_name = display_name.text if display_name is not None else channel_id
                
                # Get programmes for this channel
                for programme in root.findall(f'.//programme[@channel="{channel_id}"]'):
                    start = programme.get('start', '')
                    stop = programme.get('stop', '')
                    title_elem = programme.find('.//title')
                    title = title_elem.text if title_elem is not None else 'Unknown'
                    desc_elem = programme.find('.//desc')
                    description = desc_elem.text if desc_elem is not None else ''
                    category_elem = programme.find('.//category')
                    category = category_elem.text if category_elem is not None else ''
                    
                    programs.append({
                        'channel': channel_name,
                        'channel_id': channel_id,
                        'start': self.format_time(start),
                        'end': self.format_time(stop),
                        'title': title,
                        'description': description,
                        'genre': category
                    })
            
            return programs
            
        except ET.ParseError as e:
            log(f"XML Parse Error: {e}", xbmc.LOGERROR)
            return []
        except Exception as e:
            log(f"Error parsing EPG: {e}", xbmc.LOGERROR)
            return []
    
    def format_time(self, timestamp):
        """Format XMLTV timestamp to readable format"""
        if not timestamp:
            return ''
        
        try:
            dt = datetime.strptime(timestamp, '%Y%m%d%H%M%S %z')
            return dt.strftime('%H:%M')
        except ValueError:
            try:
                dt = datetime.strptime(timestamp[:14], '%Y%m%d%H%M%S')
                return dt.strftime('%H:%M')
            except ValueError:
                return timestamp
    
    def get_programs(self, url, proxy_handler=None):
        """Get EPG programs"""
        try:
            content = self.fetch_epg(url, proxy_handler)
            return self.parse_xmltv(content)
        except Exception as e:
            log(f"Error getting programs: {e}", xbmc.LOGERROR)
            return []
    
    def get_channel_programmes(self, url, channel_id, proxy_handler=None):
        """Get programmes for a specific channel"""
        all_programs = self.get_programs(url, proxy_handler)
        return [p for p in all_programs if p.get('channel_id') == channel_id]
    
    def clear_cache(self):
        """Clear EPG cache"""
        self.CACHE = {}