# -*- coding: utf-8 -*-
import sys
import os

__addon__ = sys.modules["__main__"].__file__
__path__ = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, __path__)

if __name__ == "__main__":
    from resources.libs.greektv import GreekTV
    GreekTV().run()