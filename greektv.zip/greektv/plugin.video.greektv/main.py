# -*- coding: utf-8 -*-
"""
GreekTV Main Plugin
Version: 1.6
"""

import sys
import os
import re
import json
import time
import urllib.request
import urllib.error
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
from . import (
    ADDON, ADDON_ID, ADDON_NAME, ADDON_VERSION, ADDON_PATH,
    ADDON_ICON, ADDON_FANART, CATEGORIES, CATEGORY_ICONS,
    get_url_kodi, get_params, log, notify, get_setting, set_setting
)

# Import resources
sys.path.insert(0, f'{ADDON_PATH}/resources/libs')
from m3u_parser import M3UParser
from proxy_handler import ProxyHandler
from epg_handler import EPGHandler

class GreekTVAddon:
    """Main GreekTV Addon Class"""
    
    def __init__(self):
        self.parser = M3UParser()
        self.proxy = ProxyHandler()
        self.epg = EPGHandler()
        self.handle = int(sys.argv[1])
        self.params = get_params()
        
        # Load settings
        self.m3u_url = get_setting('m3u_playlist_url')
        self.epg_url = get_setting('epg_url')
        self.proxy_enabled = get_setting('proxy_enabled') == 'true'
        self.proxy_type = get_setting('proxy_type')
        self.proxy_ip = get_setting('proxy_ip')
        self.proxy_port = get_setting('proxy_port')
        self.proxy_username = get_setting('proxy_username')
        self.proxy_password = get_setting('proxy_password')
        
        # Configure proxy if enabled
        if self.proxy_enabled and self.proxy_ip and self.proxy_port:
            self.proxy.configure(
                proxy_type=self.proxy_type,
                proxy_ip=self.proxy_ip,
                proxy_port=self.proxy_port,
                username=self.proxy_username,
                password=self.proxy_password
            )
    
    def run(self):
        """Main run function"""
        mode = self.params.get('mode', '')
        
        log(f"Running mode: {mode}")
        
        if mode == 'categories':
            self.show_categories()
        elif mode == 'category_items':
            self.show_category_items()
        elif mode == 'play':
            self.play_video()
        elif mode == 'search':
            self.search_content()
        elif mode == 'setup_m3u':
            self.setup_m3u()
        elif mode == 'settings':
            self.open_settings()
        elif mode == 'refresh':
            self.refresh_playlist()
        elif mode == 'epg':
            self.show_epg()
        elif mode == 'favorites':
            self.show_favorites()
        else:
            self.show_main_menu()
    
    def show_main_menu(self):
        """Show main menu with categories"""
        log("Showing main menu")
        
        # Add Settings
        self.add_item({
            'title': '⚙️ Ρυθμίσεις / Settings',
            'mode': 'settings',
            'icon': 'settings.png',
            'is_folder': True
        })
        
        # Add Categories
        for cat_id, cat_info in CATEGORIES.items():
            # Check if category is enabled
            setting_key = f"show_{cat_id.lower()}"
            if get_setting(setting_key, 'true') == 'false':
                continue
            
            self.add_item({
                'title': f"📺 {cat_info['name']}",
                'mode': 'category_items',
                'category': cat_id,
                'icon': CATEGORY_ICONS.get(cat_id, 'default.png'),
                'description': cat_info['description'],
                'is_folder': True
            })
        
        # Add EPG
        if self.epg_url:
            self.add_item({
                'title': '📋 TV Guide / Πρόγραμμα Τηλεόρασης',
                'mode': 'epg',
                'icon': 'epg.png',
                'is_folder': True
            })
        
        # Add Search
        self.add_item({
            'title': '🔍 Αναζήτηση / Search',
            'mode': 'search',
            'icon': 'search.png',
            'is_folder': True
        })
        
        # Add Refresh
        self.add_item({
            'title': '🔄 Ανανέωση Λίστας / Refresh Playlist',
            'mode': 'refresh',
            'icon': 'refresh.png',
            'is_folder': False
        })
        
        xbmcplugin.endOfDirectory(self.handle, cacheToDisc=True)
    
    def show_categories(self):
        """Show category list"""
        for cat_id, cat_info in CATEGORIES.items():
            self.add_item({
                'title': cat_info['name'],
                'mode': 'category_items',
                'category': cat_id,
                'icon': CATEGORY_ICONS.get(cat_id, 'default.png'),
                'description': cat_info['description'],
                'is_folder': True
            })
        xbmcplugin.endOfDirectory(self.handle)
    
    def show_category_items(self):
        """Show items for a specific category"""
        category = self.params.get('category', '')
        page = int(self.params.get('page', 1))
        
        if not category:
            notify(ADDON_NAME, 'No category selected')
            return
        
        log(f"Showing items for category: {category}")
        
        # Load playlist
        if not self.m3u_url:
            self.show_setup_m3u_message()
            return
        
        try:
            items = self.parser.get_items_by_category(
                self.m3u_url, 
                category,
                proxy_handler=self.proxy if self.proxy_enabled else None
            )
            
            if not items:
                # Show sample/demo items if no items found
                items = self.get_demo_items(category)
            
            for item in items:
                self.add_video_item(item)
            
            xbmcplugin.endOfDirectory(self.handle, cacheToDisc=True)
            
        except Exception as e:
            log(f"Error loading category items: {e}", xbmc.LOGERROR)
            notify(ADDON_NAME, f'Error loading content: {e}')
            xbmcplugin.endOfDirectory(self.handle)
    
    def get_demo_items(self, category):
        """Get demo items for testing"""
        demo_data = {
            'LiveTV': [
                {'name': 'ERT1', 'url': 'https://ert-live.ascdn.broadpeak.io/bpk-tv/ERT1/drm/index.mpd', 'logo': 'ert1.png', 'tvg_id': 'ERT1.gr'},
                {'name': 'ERT2', 'url': 'https://ert-live.ascdn.broadpeak.io/bpk-tv/ERT2/drm/index.mpd', 'logo': 'ert2.png', 'tvg_id': 'ERT2.gr'},
                {'name': 'ERT3', 'url': 'https://702e2e484b144c71ba38bca0d41f37cd.msvdn.net/bpk-tv/ERT3/default/index.m3u8', 'logo': 'ert3.png', 'tvg_id': 'ERT3.gr'},
                {'name': 'ANTENA', 'url': 'https://raw.githubusercontent.com/jimgate07/grtv/refs/heads/master/Metadoseis/antenna.m3u8', 'logo': 'antena.png', 'tvg_id': 'ANTENA.gr'},
                {'name': 'STAR', 'url': 'https://livestar.siliconweb.com/media/star4/star4newhd.m3u8', 'logo': 'star.png', 'tvg_id': 'STAR.gr'},
                {'name': 'ALPHA', 'url': 'https://alphatvlive2.siliconweb.com/alphatvlive/live_abr/alphatvlive/live_source/playlist.m3u8', 'logo': 'alpha.png', 'tvg_id': 'ALPHA.gr'},
                {'name': 'MEGA', 'url': 'http://127.0.0.1:50199/mega.flv?ws=d3NzOi8vYW1zNC1lZGdlLTAzLmNkbi52aW5kcmFsLmNvbS9zdWJzY3JpYmU_Y2hhbm5lbElkPWFsdGVyZWdvbWVkaWFfbWVnYXR2MV9jaV82Y2M0OTBjNy1lNWM2LTQ4NmItYWNmMC05YmI5YzIwZmE2NzAmYXVkaW8uY29kZWM9YWFjJmF1ZGlvLmJpdFJhdGU9MTI4MDAwJnZpZGVvLmNvZGVjPWgyNjQmdmlkZW8ud2lkdGg9MTI4MCZ2aWRlby5oZWlnaHQ9NzIwJnZpZGVvLmJpdFJhdGU9MzAwMDAwMCZidXJzdE1zPTIwMDA=&origin=https%3A//www.megatv.com', 'logo': 'mega.png', 'tvg_id': 'MEGA.gr'},
                {'name': 'SKAI', 'url': 'https://skai-live.siliconweb.com/media/cambria4/index_media_bitrate2000K_avc1_mp4a.m3u8', 'logo': 'skai.png', 'tvg_id': 'SKAI.gr'},
            ],
            'SEFLIX': [
                {'name': '50 αποχρώσεις του Greece part 1', 'url': 'https://www.dailymotion.com/video/x7v7jmb', 'logo': 'https://www.comedyfactory.gr/wp-content/uploads/2024/03/DELFINARIO_BANNER_COMEDY_FACTORY_50AP.jpg'},
                {'name': '50 αποχρώσεις του Greece part 2', 'url': 'https://www.dailymotion.com/video/x7v7jma', 'logo': 'https://www.comedyfactory.gr/wp-content/uploads/2024/03/DELFINARIO_BANNER_COMEDY_FACTORY_50AP.jpg'},
                {'name': '10 xronia gamou part 1', 'url': 'https://www.dailymotion.com/video/x95buey', 'logo': 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRMWfjEkgGM1qWCFWTjN-mef9uCPrrCc4YRJw&s'},
                {'name': '10 xronia gamou part 2', 'url': 'https://www.dailymotion.com/video/x95buew', 'logo': 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRMWfjEkgGM1qWCFWTjN-mef9uCPrrCc4YRJw&s'},
                {'name': 'Fame Zori', 'url': 'https://www.dailymotion.com/video/xa1i7p6', 'logo': 'https://musicalparadise.com/wp-content/uploads/2020/07/Famezori1.JPG'},
            ],
            'GREEKMOVIES': [
                {'name': 'Λαβ Καίσαρ', 'url': 'http://example.com/labkaesar.m3u8', 'logo': 'labkaesar.png'},
                {'name': 'Η Νίκη Την Καλεί', 'url': 'http://example.com/niki.m3u8', 'logo': 'niki.png'},
                {'name': 'Ο Μπλοκ της Γειτονιάς', 'url': 'http://example.com/mplok.m3u8', 'logo': 'mplok.png'},
                {'name': 'Μανταλένα', 'url': 'http://example.com/mantaleia.m3u8', 'logo': 'mantaleia.png'},
            ],
            'JESUSMOVIES': [
                {'name': 'Ο Υιός του Θεού', 'url': 'http://example.com/yios.m3u8', 'logo': 'jesus.png'},
                {'name': 'Η Βασιλεία των Ουρανών', 'url': 'http://example.com/vasileia.m3u8', 'logo': 'jesus.png'},
                {'name': 'Πάσιμπαλ - Η Μεγάλη Ιστορία', 'url': 'http://example.com/pasipal.m3u8', 'logo': 'jesus.png'},
            ],
            'KIDSMOVIES': [
                {'name': 'Ο Μικρός Νικόλας', 'url': 'http://example.com/nikolaos.m3u8', 'logo': 'kids.png'},
                {'name': 'Τα Τέσσερα Φτερά', 'url': 'http://example.com/ftera.m3u8', 'logo': 'kids.png'},
                {'name': 'Ο Καλός μου Φίλος', 'url': 'http://example.com/filos.m3u8', 'logo': 'kids.png'},
            ],
            'ALIKI': [
                {'name': 'Η Αλίκη στα Σόσιαλ', 'url': 'http://example.com/aliki1.m3u8', 'logo': 'aliki.png'},
                {'name': 'Κατηγορώ την Μοίρα μου', 'url': 'http://example.com/aliki2.m3u8', 'logo': 'aliki.png'},
                {'name': 'Προσοχή, Μωρό μου', 'url': 'http://example.com/aliki3.m3u8', 'logo': 'aliki.png'},
                {'name': 'Κάτι Να Κάψει', 'url': 'http://example.com/aliki4.m3u8', 'logo': 'aliki.png'},
                {'name': 'Μια Γυναίκα Έκανε τον Ντίκ', 'url': 'http://example.com/aliki5.m3u8', 'logo': 'aliki.png'},
            ]
        }
        
        return demo_data.get(category, [])
    
    def add_item(self, item_info):
        """Add item to directory"""
        title = item_info.get('title', 'Unknown')
        mode = item_info.get('mode', '')
        icon = item_info.get('icon', ADDON_ICON)
        
        # Build icon path
        if icon and not icon.startswith('http'):
            icon_path = xbmcvfs.translatePath(f'{ADDON_PATH}/resources/media/{icon}')
            if not xbmcvfs.exists(icon_path):
                icon_path = ADDON_ICON
        else:
            icon_path = icon if icon else ADDON_ICON
        
        list_item = xbmcgui.ListItem(label=title)
        list_item.setArt({
            'icon': icon_path,
            'fanart': ADDON_FANART
        })
        
        if item_info.get('description'):
            list_item.setInfo('video', {
                'plot': item_info['description'],
                'title': title
            })
        
        url = get_url_kodi({
            'mode': mode,
            'category': item_info.get('category', ''),
            'name': item_info.get('name', ''),
            'url': item_info.get('url', '')
        })
        
        is_folder = item_info.get('is_folder', True)
        xbmcplugin.addDirectoryItem(
            self.handle, 
            url, 
            list_item, 
            isFolder=is_folder
        )
    
    def add_video_item(self, item_info):
        """Add video item to directory"""
        title = item_info.get('name', item_info.get('title', 'Unknown'))
        url = item_info.get('url', '')
        logo = item_info.get('logo', '')
        
        # Build logo path
        if logo and not logo.startswith('http'):
            logo_path = xbmcvfs.translatePath(f'{ADDON_PATH}/resources/media/{logo}')
            if not xbmcvfs.exists(logo_path):
                logo_path = ADDON_ICON
        else:
            logo_path = logo if logo else ADDON_ICON
        
        list_item = xbmcgui.ListItem(label=title)
        list_item.setArt({
            'icon': logo_path,
            'fanart': ADDON_FANART,
            'poster': logo_path,
            'thumb': logo_path
        })
        
        # Set info
        info_labels = {
            'title': title,
            'plot': item_info.get('description', item_info.get('plot', '')),
            'genre': item_info.get('genre', ''),
            'year': item_info.get('year', 0),
            'duration': item_info.get('duration', 0),
        }
        
        if item_info.get('tvg_id'):
            info_labels['episode'] = item_info.get('episode', 0)
            info_labels['season'] = item_info.get('season', 0)
        
        list_item.setInfo('video', info_labels)
        
        # Set stream info
        if item_info.get('url'):
            list_item.setProperty('IsPlayable', 'true')
        
        # Build URL
        item_url = get_url_kodi({
            'mode': 'play',
            'url': url,
            'name': title,
            'logo': logo_path
        })
        
        xbmcplugin.addDirectoryItem(
            self.handle,
            item_url,
            list_item,
            isFolder=False
        )
    
    def play_video(self):
        """Play video stream"""
        url = self.params.get('url', '')
        name = self.params.get('name', 'Video')
        
        if not url:
            notify(ADDON_NAME, 'No URL provided')
            return
        
        log(f"Playing: {name} - URL: {url}")
        
        # Apply proxy if enabled
        if self.proxy_enabled:
            url = self.proxy.get_proxy_url(url)
        
        # Create playable item
        list_item = xbmcgui.ListItem(label=name)
        list_item.setPath(url)
        list_item.setProperty('IsPlayable', 'true')
        
        # Set subtitles if available
        if self.params.get('subtitles'):
            list_item.setSubtitles([self.params.get('subtitles')])
        
        # Play
        xbmcplugin.setResolvedUrl(self.handle, True, list_item)
    
    def search_content(self):
        """Search content"""
        search_query = xbmcgui.Dialog().input(
            'Αναζήτηση / Search',
            type=xbmcgui.INPUT_ALPHANUM
        )
        
        if not search_query:
            return
        
        log(f"Searching for: {search_query}")
        
        if self.m3u_url:
            try:
                items = self.parser.search_items(
                    self.m3u_url,
                    search_query,
                    proxy_handler=self.proxy if self.proxy_enabled else None
                )
                
                for item in items:
                    self.add_video_item(item)
                
                xbmcplugin.endOfDirectory(self.handle)
            except Exception as e:
                log(f"Search error: {e}", xbmc.LOGERROR)
                notify(ADDON_NAME, 'Search failed')
                xbmcplugin.endOfDirectory(self.handle)
        else:
            self.show_setup_m3u_message()
    
    def setup_m3u(self):
        """Setup M3U URL"""
        dialog = xbmcgui.Dialog()
        
        # Get current URL
        current_url = get_setting('m3u_playlist_url')
        
        # Input new URL
        url = dialog.input(
            'Εισάγετε URL Λίστας M3U / Enter M3U Playlist URL',
            defaultt=current_url,
            type=xbmcgui.INPUT_ALPHANUM
        )
        
        if url:
            set_setting('m3u_playlist_url', url)
            notify(ADDON_NAME, 'Playlist URL updated')
            self.m3u_url = url
    
    def show_setup_m3u_message(self):
        """Show setup M3U message"""
        dialog = xbmcgui.Dialog()
        
        if dialog.yesno(
            ADDON_NAME,
            'M3U Playlist URL not configured.\nDo you want to set it now?'
        ):
            self.setup_m3u()
    
    def open_settings(self):
        """Open addon settings"""
        ADDON.openSettings()
    
    def refresh_playlist(self):
        """Refresh playlist cache"""
        xbmc.executebuiltin('Container.Refresh')
        notify(ADDON_NAME, 'Playlist refreshed')
    
    def show_epg(self):
        """Show EPG guide"""
        if not self.epg_url:
            notify(ADDON_NAME, 'EPG URL not configured')
            return
        
        try:
            programs = self.epg.get_programs(
                self.epg_url,
                proxy_handler=self.proxy if self.proxy_enabled else None
            )
            
            for program in programs:
                self.add_epg_item(program)
            
            xbmcplugin.endOfDirectory(self.handle)
        except Exception as e:
            log(f"EPG error: {e}", xbmc.LOGERROR)
            notify(ADDON_NAME, 'Failed to load EPG')
    
    def add_epg_item(self, program):
        """Add EPG program item"""
        title = f"{program.get('channel', 'Unknown')} - {program.get('title', 'Unknown')}"
        start_time = program.get('start', '')
        end_time = program.get('end', '')
        
        list_item = xbmcgui.ListItem(label=title)
        list_item.setInfo('video', {
            'title': program.get('title', ''),
            'plot': f"{start_time} - {end_time}\n{program.get('description', '')}",
            'genre': program.get('genre', '')
        })
        
        xbmcplugin.addDirectoryItem(
            self.handle,
            '',
            list_item,
            isFolder=False
        )
    
    def show_favorites(self):
        """Show favorites"""
        favorites = json.loads(get_setting('favorites', '[]'))
        
        if not favorites:
            notify(ADDON_NAME, 'No favorites yet')
            return
        
        for fav in favorites:
            self.add_video_item(fav)
        
        xbmcplugin.endOfDirectory(self.handle)

def run():
    """Entry point"""
    addon = GreekTVAddon()
    addon.run()