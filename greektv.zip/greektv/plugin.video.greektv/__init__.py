# -*- coding: utf-8 -*-
"""
GreekTV Kodi Addon
Version: 1.0.3
Python: 3.12 Compatible
Kodi: 21.3 Compatible
"""

__all__ = [
    'get_url_kodi',
    'get_params',
    'log',
    'notify',
    'CATEGORIES',
    'CATEGORY_ICONS'
]

import sys
import re
import json
import urllib.parse
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

# Addon Info
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_VERSION = ADDON.getAddonInfo('version')
ADDON_PATH = ADDON.getAddonInfo('path')
ADDON_ICON = xbmcvfs.translatePath(f'{ADDON_PATH}/resources/media/icon.png')
ADDON_FANART = xbmcvfs.translatePath(f'{ADDON_PATH}/resources/media/fanart.jpg')

# Base URL
BASE_URL = sys.argv[0]

# Categories Definition
CATEGORIES = {
    'LiveTV': {
        'name': 'LiveTV',
        'description': 'Greek Live TV Channels - Ζωντανή Ελληνική Τηλεόραση',
        'icon': 'livetv.png',
        'fanart': 'livetv_fanart.jpg'
    },
    'SEFLIX': {
        'name': 'SEFLIX',
        'description': 'Greek Series & Shows - Ελληνικές Σειρές',
        'icon': 'seflix.png',
        'fanart': 'seflix_fanart.jpg'
    },
    'GREEKMOVIES': {
        'name': 'GREEKMOVIES',
        'description': 'Greek Movies Collection - Ελληνικές Ταινίες',
        'icon': 'greekmovies.png',
        'fanart': 'greekmovies_fanart.jpg'
    },
    'JESUSMOVIES': {
        'name': 'JESUSMOVIES',
        'description': 'Christian Movies - Χριστιανικές Ταινίες',
        'icon': 'jesusmovies.png',
        'fanart': 'jesusmovies_fanart.jpg'
    },
    'KIDSMOVIES': {
        'name': 'KIDSMOVIES',
        'description': 'Kids Movies & Cartoons - Παιδικές Ταινίες',
        'icon': 'kidsmovies.png',
        'fanart': 'kidsmovies_fanart.jpg'
    },
    'ALIKI': {
        'name': 'ALIKI VOUGIOUKLAKI TENIES',
        'description': 'Aliki Vougiouklaki Collection - Συλλογή Αλίκης Βουγιουκλάκη',
        'icon': 'aliki.png',
        'fanart': 'aliki_fanart.jpg'
    }
}

CATEGORY_ICONS = {
    'LiveTV': 'livetv.png',
    'SEFLIX': 'seflix.png',
    'GREEKMOVIES': 'greekmovies.png',
    'JESUSMOVIES': 'jesusmovies.png',
    'KIDSMOVIES': 'kidsmovies.png',
    'ALIKI': 'aliki.png'
}

def get_url_kodi(encoded_params):
    """Build URL with proper encoding for Kodi"""
    return f"{BASE_URL}?{urllib.parse.urlencode(encoded_params)}"

def get_params():
    """Parse URL parameters"""
    param_string = sys.argv[2]
    if not param_string:
        return {}
    param_string = urllib.parse.unquote_plus(param_string)
    return dict(urllib.parse.parse_qsl(param_string))

def log(message, level=xbmc.LOGINFO):
    """Logging function"""
    xbmc.log(f"[{ADDON_NAME}] {message}", level)

def notify(title, message, icon=ADDON_ICON, time=5000):
    """Show notification"""
    xbmcgui.Dialog().notification(title, message, icon, time)

def get_setting(setting_id, default=''):
    """Get addon setting"""
    try:
        value = ADDON.getSetting(setting_id)
        if value is None:
            return default
        return value
    except Exception as e:
        log(f"Error getting setting {setting_id}: {e}", xbmc.LOGERROR)
        return default

def set_setting(setting_id, value):
    """Set addon setting"""
    try:
        ADDON.setSetting(setting_id, value)
        return True
    except Exception as e:
        log(f"Error setting {setting_id}: {e}", xbmc.LOGERROR)
        return False